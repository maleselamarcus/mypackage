# my package
This library was created as an example of how to create your own package.
## Building this package locally
